<?php include 'config.php'; ?>
<!doctype html><html><head><meta charset="utf-8"><title>Glow Bot</title><link rel="stylesheet" href="assets/style.css"></head><body>
<header class="site-header"><h1>Glow Bot</h1></header>
<main class="container"><h2>Welcome to Glow Bot</h2><p><a class="btn" href="survey.php">Take Survey</a> <a class="btn outline" href="scan.php">Skin Scan</a></p></main>
</body></html>